package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private ListView lista;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        lista = findViewById(R.id.lista);

        llenarLista();
    }

    public void llenarLista(){
        String[] listitem = { "item1 ", "item12 ", "item13 ","item1 "};
        ArrayAdapter <String> adaptador = new ArrayAdapter<>(getApplicationContext(),
                android.R.layout.simple_list_item_single_choice);
        lista.setAdapter(adaptador);
    }
}